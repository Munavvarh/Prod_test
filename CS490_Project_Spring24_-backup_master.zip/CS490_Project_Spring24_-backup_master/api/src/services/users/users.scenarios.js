export const standard = defineScenario({
  user: {
    one: {
      data: {
        email: 'String9601669',
        hashedPassword: 'String',
        salt: 'String',
      },
    },
    two: {
      data: {
        email: 'String8549726',
        hashedPassword: 'String',
        salt: 'String',
      },
    },
  },
})
