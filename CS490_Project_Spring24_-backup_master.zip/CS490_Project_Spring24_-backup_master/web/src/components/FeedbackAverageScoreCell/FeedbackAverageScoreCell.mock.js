export const standard = () => ({
  feedbacks: [
    {
      id: 1,
      score: 5,
    },
    {
      id: 2,
      score: 4,
    },
  ],
})
