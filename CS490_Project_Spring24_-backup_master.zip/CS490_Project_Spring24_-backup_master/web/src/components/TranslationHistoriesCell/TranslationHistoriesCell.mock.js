// Define your own mock data here:
export const standard = (/* vars, { ctx, req } */) => ({
  translationHistories: [{ id: 42 }, { id: 43 }, { id: 44 }],
})
