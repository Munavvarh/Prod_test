import LoginPage from './LoginPage'

const meta = {
  component: LoginPage,
}

export default meta

export const Primary = {}
