import TranslationOutputPage from './TranslationOutputPage'

const meta = {
  component: TranslationOutputPage,
}

export default meta

export const Primary = {}
