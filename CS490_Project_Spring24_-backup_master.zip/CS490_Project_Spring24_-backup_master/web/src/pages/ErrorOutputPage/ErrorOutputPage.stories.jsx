import ErrorOutputPage from './ErrorOutputPage'

const meta = {
  component: ErrorOutputPage,
}

export default meta

export const Primary = {}
