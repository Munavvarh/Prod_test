import AdminNavigatePage from './AdminNavigatePage'

const meta = {
  component: AdminNavigatePage,
}

export default meta

export const Primary = {}
