import ContactOutputPage from './ContactOutputPage'

const meta = {
  component: ContactOutputPage,
}

export default meta

export const Primary = {}
