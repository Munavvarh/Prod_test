import SignupPage from './SignupPage'

const meta = {
  component: SignupPage,
}

export default meta

export const Primary = {}
