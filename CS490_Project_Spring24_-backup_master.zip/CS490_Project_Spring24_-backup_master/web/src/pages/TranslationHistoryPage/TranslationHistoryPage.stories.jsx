import TranslationHistoryPage from './TranslationHistoryPage'

const meta = {
  component: TranslationHistoryPage,
}

export default meta

export const Primary = {}
