import UserFeedbackOutputPage from './UserFeedbackOutputPage'

const meta = {
  component: UserFeedbackOutputPage,
}

export default meta

export const Primary = {}
