import DocumentationPage from './DocumentationPage'

const meta = {
  component: DocumentationPage,
}

export default meta

export const Primary = {}
