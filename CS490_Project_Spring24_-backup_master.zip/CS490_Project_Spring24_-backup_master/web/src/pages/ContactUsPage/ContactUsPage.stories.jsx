import ContactUsPage from './ContactUsPage'

const meta = {
  component: ContactUsPage,
}

export default meta

export const Primary = {}
