import HomePage from './HomePage'

const meta = {
  component: HomePage,
}

export default meta

export const Primary = {}
