import UserCell from 'src/components/User/UserCell'

const UserPage = ({ id }) => {
  return <UserCell id={id} />
}

export default UserPage
