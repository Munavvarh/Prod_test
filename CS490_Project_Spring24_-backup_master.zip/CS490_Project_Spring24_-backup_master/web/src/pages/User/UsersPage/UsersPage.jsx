import UsersCell from 'src/components/User/UsersCell'

const UsersPage = () => {
  return <UsersCell />
}

export default UsersPage
