import NewUser from 'src/components/User/NewUser'

const NewUserPage = () => {
  return <NewUser />
}

export default NewUserPage
