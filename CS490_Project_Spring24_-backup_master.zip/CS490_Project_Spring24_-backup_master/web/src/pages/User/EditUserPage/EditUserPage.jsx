import EditUserCell from 'src/components/User/EditUserCell'

const EditUserPage = ({ id }) => {
  return <EditUserCell id={id} />
}

export default EditUserPage
