import MainLayout from './MainLayout'

const meta = {
  component: MainLayout,
}

export default meta

export const Primary = {}
